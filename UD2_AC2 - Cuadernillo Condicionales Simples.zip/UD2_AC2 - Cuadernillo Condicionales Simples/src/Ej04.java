public class Ej04 {
    public static void main(String[] args) {
        double precio = 80;
        boolean clienteVIP = true;
        boolean descuentoActivo = false;

        if (precio >= 50 && clienteVIP || descuentoActivo) {
            double precioFinal = precio * 0.85;
            System.out.println("El precio final es: " + precioFinal);
        }
    }
    
}
