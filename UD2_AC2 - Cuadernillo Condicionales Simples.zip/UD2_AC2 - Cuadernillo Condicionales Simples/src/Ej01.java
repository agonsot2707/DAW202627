import java.util.Scanner;
public class Ej01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce tu edad: ");
        int edad = sc.nextInt();
        System.out.println("Posees carnet: ");
        boolean tieneCarnet = sc.nextBoolean();

        if (edad >= 18 && edad <=65 && tieneCarnet ){
            System.out.println("Acceso permitido");

        }
        sc.close();

        
    }
}
