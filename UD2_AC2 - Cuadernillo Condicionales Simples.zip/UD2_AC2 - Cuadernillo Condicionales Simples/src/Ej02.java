import java.util.Scanner;
public class Ej02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce la temperatura: ");
        int temperatura = sc.nextInt();
        System.out.println("Esta lloviendo: ");
        boolean llueve = sc.nextBoolean();

        if (temperatura > 25 && temperatura < 36 && !llueve) {
            System.out.println("Dia perfecto para la playa");
        }
        sc.close();
    
}
}