import java.util.Scanner;
public class Ej07 {
    public static void main(String[] args) {
        
        
    }
    
}
